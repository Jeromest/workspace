> **项目：vueblog**
>
> **公众号：MarkerHub**

### 介绍

一个基于SpringBoot + Vue开发的前后端分离博客项目，带有超级详细开发文档和讲解视频。还未接触过vue开发，或者前后端分离的同学，学起来哈。别忘了给vueblog一个star！感谢

### 技术栈：

![](https://oscimg.oschina.net/oscnet/up-4626cb696c003e36c4515e77adc7632c6ed.png)

### 项目效果：

![图片](https://image-1300566513.cos.ap-guangzhou.myqcloud.com/upload/images/20200613/b1c18a3fe33544578971c3a15d0d9425.png)

![图片](https://image-1300566513.cos.ap-guangzhou.myqcloud.com/upload/images/20200613/5e291faeaef648af87b8b33483eef5bd.png)


### 项目文档：

开发文档：https://juejin.im/post/5ecfca676fb9a04793456fb8

vue入门视频：https://www.bilibili.com/video/BV125411W73W/

**vueblog讲解视频：** https://www.bilibili.com/video/BV1PQ4y1P7hZ/

关注我的B站，后续陆续还有

* 前后端分离类百度搜索引擎项目
* 即时聊天等项目

等项目分享出来哈！

**更多项目请关注公众号：MarkerHub**

![MarkerHub](https://camo.githubusercontent.com/061df651b4fcfec5d258dc2beb78f441b9360e42/68747470733a2f2f696d6167652d313330303536363531332e636f732e61702d6775616e677a686f752e6d7971636c6f75642e636f6d2f6d696e652f4d61726b65724875622e6a7067)
