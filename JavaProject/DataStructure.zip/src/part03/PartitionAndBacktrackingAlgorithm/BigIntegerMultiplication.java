package part03.PartitionAndBacktrackingAlgorithm;

public class BigIntegerMultiplication {
    public static void main(String[] args) {
        System.out.println("Hello");
    }
}
